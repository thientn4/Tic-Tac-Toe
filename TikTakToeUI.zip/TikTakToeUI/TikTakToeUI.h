
// TikTakToeUI.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'pch.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols


// CTikTakToeUIApp:
// See TikTakToeUI.cpp for the implementation of this class
//

class CTikTakToeUIApp : public CWinApp
{
public:
	CTikTakToeUIApp();

// Overrides
public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
};

extern CTikTakToeUIApp theApp;
