#include <list>
#include "Option.h"

#pragma once

class CTikTakToeUIDlg : public CDialogEx
{
public:
	CTikTakToeUIDlg(CWnd* pParent = nullptr);
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_TIKTAKTOEUI_DIALOG };
#endif
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);

protected:
	HICON m_hIcon;
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton11();
	afx_msg void OnBnClickedButton12();
	afx_msg void OnBnClickedButton13();
	afx_msg void OnBnClickedButton21();
	afx_msg void OnBnClickedButton22();
	afx_msg void OnBnClickedButton23();
	afx_msg void OnBnClickedButton31();
	afx_msg void OnBnClickedButton32();
	afx_msg void OnBnClickedButton33();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedCancel2();
	afx_msg int getButton(int ij);
	afx_msg void AI(char XandO[3][3]);
	void CTikTakToeUIDlg::endGame(char player, char XandO[3][3]);
	void CTikTakToeUIDlg::setFont(int ij, bool bold);
};
