#include <list>
#include "Option.h"
#include "pch.h"
#include "framework.h"
#include "TikTakToeUI.h"
#include "TikTakToeUIDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif
using namespace std;


char XandO[3][3];
int win = 0;
int loss = 0;
int tie = 0;
bool stupid = false;

bool isEmpty(char onClick) {
	if (onClick == 'X' || onClick == 'O')
		return false;
	return true;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

bool endYet(char player, char XandO[3][3]) {
	int countRightSlash = 0;
	int countLeftSlash = 0;
	for (int i = 0; i < 3; i++) {
		int countRow = 0;
		int countLine = 0;
		if (XandO[i][i] == player)
			countRightSlash++;
		if (XandO[i][3 - 1 - i] == player)
			countLeftSlash++;
		for (int j = 0; j < 3; j++) {
			if (XandO[i][j] == player)
				countRow++;
			if (XandO[j][i] == player)
				countLine++;
		}
		if (countRow == 3 || countLine == 3) {
			return true;
		}
	}
	if (countRightSlash == 3 || countLeftSlash == 3)
		return true;
	return false;
}
bool tieYet(char XandO[3][3]) {
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
			if (XandO[i][j] != 'X' && XandO[i][j] != 'O')
				return false;
	return true;
}
bool allEmpty(char XandO[3][3]) {
	for (int i = 0; i < 3; i++)
		for (int j = 0; j < 3; j++)
			if (XandO[i][j] == 'X' || XandO[i][j] == 'O')
				return false;
	return true;
}
int CTikTakToeUIDlg::getButton(int ij) {
	int xy = ij + 11;
	if (xy == 12)return IDC_BUTTON12;
	if (xy == 13)return IDC_BUTTON13;
	if (xy == 21)return IDC_BUTTON21;
	if (xy == 22)return IDC_BUTTON22;
	if (xy == 23)return IDC_BUTTON23;
	if (xy == 31)return IDC_BUTTON31;
	if (xy == 32)return IDC_BUTTON32;
	if (xy == 33)return IDC_BUTTON33;
	return IDC_BUTTON11;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////


pair<int, int> attack(int nextMove, char nextPlayer, char current[3][3]) {
	int lWin = 0;
	int lLoss = 0;
	current[nextMove / 10][nextMove % 10] = nextPlayer;

	char nextNextPlayer = 'X';
	if (nextPlayer == 'X')nextNextPlayer = 'O';

	int potentialEnd = 0;
	for (int i = 0;i < 3;i++) {
		for (int j = 0; j < 3; j++) {
			if (isEmpty(current[i][j])) {
				char predict[3][3];
				for (int a = 0; a < 3; a++)
					for (int b = 0; b < 3; b++) {
						predict[a][b] = current[a][b];
					}
				predict[i][j] = nextNextPlayer;
				if (endYet(nextNextPlayer, predict)) {
					potentialEnd++;
				}
			}
		}
	}

	if (potentialEnd != 0) {
		if (nextNextPlayer == 'X')
			return make_pair(0, potentialEnd);
		return make_pair(potentialEnd, 0);
	}

	for (int i = 0;i < 3;i++) {
		for (int j = 0; j < 3; j++) {
			if (isEmpty(current[i][j])) {
				char afterCurrent[3][3];
				for (int a = 0; a < 3; a++)
					for (int b = 0; b < 3; b++)
						afterCurrent[a][b] = current[a][b];
				pair<int, int> nextPair = attack(i * 10 + j, nextNextPlayer, afterCurrent);
				lWin += nextPair.first;
				lLoss += nextPair.second;
			}
		}
	}
	return make_pair(lWin, lLoss);
}

/*
void CTikTakToeUIDlg::AI(char XandO[3][3]) {
	unsigned seed = time(0);
	srand(seed);
	int xRand = rand() % 3;
	int yRand = rand() % 3;
	while (!isEmpty(XandO[xRand][yRand])) {
		xRand = rand() % 3;
		yRand = rand() % 3;
	}
	int ai = xRand * 10 + yRand;
	XandO[ai / 10][ai % 10] = 'O';
	setFont(ai, false);
	GetDlgItem(getButton(ai))->SetWindowTextW(L"O");
	endGame('O', XandO);
}
*/

void CTikTakToeUIDlg::AI(char XandO[3][3]) {
	int ai;
	if (!stupid) {
		list <Option>optionList;
		int instantWin = -1;
		int instantLoss = -1;
		for (int i = 0; i < 3; i++)
			for (int j = 0; j < 3; j++) {
				if (isEmpty(XandO[i][j])) {
					char current[3][3];
					char predictWin[3][3];
					char predictLoss[3][3];
					for (int a = 0; a < 3; a++)
						for (int b = 0; b < 3; b++) {
							current[a][b] = XandO[a][b];
							predictWin[a][b] = XandO[a][b];
							predictLoss[a][b] = XandO[a][b];
						}
					predictWin[i][j] = 'O';
					predictLoss[i][j] = 'X';
					if (endYet('O', predictWin)) {
						instantWin = i * 10 + j;
					}
					if (endYet('X', predictLoss)) {
						instantLoss = i * 10 + j;
					}
					if (!endYet('O', predictWin) && !endYet('X', predictLoss)) {
						Option lOption;
						lOption.mOrder = i * 10 + j;
						pair<int, int> thisPair = attack(lOption.mOrder, 'O', current);
						lOption.mCountWin = thisPair.first;
						lOption.mCountLoss = thisPair.second;
						optionList.push_back(lOption);
					}
				}
			}
		if (instantWin != -1)
			ai = instantWin;
		else if (instantLoss != -1)
			ai = instantLoss;
		else if (instantWin == -1 && instantLoss == -1) {
			Option lHighest = optionList.front();
			for (auto i : optionList) {
				if (i > lHighest) {
					lHighest = i;
				}
			}
			ai = lHighest.mOrder;
		}
	}
	else {
		unsigned seed = time(0);
		srand(seed);
		int xRand = rand() % 3;
		int yRand = rand() % 3;
		while (!isEmpty(XandO[xRand][yRand])) {
			xRand = rand() % 3;
			yRand = rand() % 3;
		}
		ai = xRand * 10 + yRand;
	}
	XandO[ai / 10][ai % 10] = 'O';
	setFont(ai, false);
	GetDlgItem(getButton(ai))->SetWindowTextW(L"O");
	endGame('O', XandO);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

CTikTakToeUIDlg::CTikTakToeUIDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_TIKTAKTOEUI_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTikTakToeUIDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CTikTakToeUIDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON11, &CTikTakToeUIDlg::OnBnClickedButton11)
	ON_BN_CLICKED(IDC_BUTTON12, &CTikTakToeUIDlg::OnBnClickedButton12)
	ON_BN_CLICKED(IDC_BUTTON13, &CTikTakToeUIDlg::OnBnClickedButton13)
	ON_BN_CLICKED(IDC_BUTTON21, &CTikTakToeUIDlg::OnBnClickedButton21)
	ON_BN_CLICKED(IDC_BUTTON22, &CTikTakToeUIDlg::OnBnClickedButton22)
	ON_BN_CLICKED(IDC_BUTTON23, &CTikTakToeUIDlg::OnBnClickedButton23)
	ON_BN_CLICKED(IDC_BUTTON31, &CTikTakToeUIDlg::OnBnClickedButton31)
	ON_BN_CLICKED(IDC_BUTTON32, &CTikTakToeUIDlg::OnBnClickedButton32)
	ON_BN_CLICKED(IDC_BUTTON33, &CTikTakToeUIDlg::OnBnClickedButton33)
	ON_BN_CLICKED(IDCANCEL, &CTikTakToeUIDlg::OnBnClickedCancel)
	ON_BN_CLICKED(IDCANCEL2, &CTikTakToeUIDlg::OnBnClickedCancel2)
END_MESSAGE_MAP()

BOOL CTikTakToeUIDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();
	SetIcon(m_hIcon, TRUE);			
	SetIcon(m_hIcon, FALSE);		
	return TRUE;
}


void CTikTakToeUIDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

HCURSOR CTikTakToeUIDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CTikTakToeUIDlg::setFont(int ij, bool bold=true) {
	CFont* font = new CFont;
	if (bold) {
		font->CreateFontW(90, 0, 0, 0, FW_HEAVY, FALSE, FALSE, 0, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, _T("Arial"));
	}
	else {
		font->CreateFontW(45, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, 0, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, _T("Arial"));
	}
	GetDlgItem(getButton(ij))->SetFont(font);
}

void CTikTakToeUIDlg::endGame(char player, char XandO[3][3]) {
	list<int> rightSlash;
	list<int> leftSlash;
	bool checkEnd = false;
	bool checkTie = true;
	for (int i = 0; i < 3; i++) {
		list<int> row;
		list<int> line;
		if (XandO[i][i] == player) {
			rightSlash.push_back(i * 11);
		}
		if (XandO[i][2 - i] == player) {
			leftSlash.push_back(i * 10 + (2 - i));
		}
		for (int j = 0; j < 3; j++) {
			if (XandO[i][j] == player)
				row.push_back(i * 10 + j);
			if (XandO[j][i] == player)
				line.push_back(j * 10 + i);
			if (isEmpty(XandO[i][j]))
				checkTie = false;
		}
		if (row.size() == 3) {
			for (auto ij : row) {
				setFont(ij);
			}
			checkEnd = true;
		}
		if (line.size() == 3) {
			for (auto ij : line) {
				setFont(ij);
			}
			checkEnd = true;
		}
	}
	if (rightSlash.size() == 3) {
		for (auto ij : rightSlash) {
			setFont(ij);
		}
		checkEnd = true;
	}
	if (leftSlash.size() == 3) {
		for (auto ij : leftSlash) {
			setFont(ij);
		}
		checkEnd = true;
	}
	if (checkEnd||checkTie) {
		int buttonCode;
		int score;
		if (checkEnd) {
			if (player == 'X') {
				win++;
				buttonCode = IDC_STATIC8;
				score = win;
			}
			else if (player == 'O') {
				loss++;
				buttonCode = IDC_STATIC7;
				score = loss;
			}
		}
		else {
			tie++;
			buttonCode = IDC_STATIC6;
			score = tie;
		}
		char tmpStr[10] = { '\0' };
		sprintf_s(tmpStr, "%d", score);
		size_t newsize = strlen(tmpStr) + 1;
		wchar_t* printScore = new wchar_t[newsize];
		size_t convertedChars = 0;
		mbstowcs_s(&convertedChars, printScore, newsize, tmpStr, _TRUNCATE);
		GetDlgItem(buttonCode)->SetWindowTextW(printScore);
	}
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void CTikTakToeUIDlg::OnBnClickedButton11()
{
	if (!endYet('X', XandO) && !endYet('O', XandO))
	if (isEmpty(XandO[0][0])) {
		setFont(00, false);
		GetDlgItem(IDC_BUTTON11)->SetWindowTextW(L"X");
		XandO[0][0] = 'X';
		endGame('X', XandO);
		if (!(tieYet(XandO) || endYet('X',XandO) || endYet('O', XandO))) {
			AI(XandO);
		}
	}
}


void CTikTakToeUIDlg::OnBnClickedButton12()
{
	if (!endYet('X', XandO) && !endYet('O', XandO))
	if (isEmpty(XandO[0][1])) {
		setFont(01, false);
		GetDlgItem(IDC_BUTTON12)->SetWindowTextW(L"X");
		XandO[0][1] = 'X';
		endGame('X', XandO);
		if (!(tieYet(XandO) || endYet('X', XandO) || endYet('O', XandO))) {
			AI(XandO);
		}
	}
}


void CTikTakToeUIDlg::OnBnClickedButton13()
{
	if(!endYet('X', XandO) && !endYet('O', XandO))
	if (isEmpty(XandO[0][2])) {
		setFont(02, false);
		GetDlgItem(IDC_BUTTON13)->SetWindowTextW(L"X");
		XandO[0][2] = 'X';
		endGame('X', XandO);
		if (!(tieYet(XandO) || endYet('X', XandO) || endYet('O', XandO))) {
			AI(XandO);
		}
	}
}


void CTikTakToeUIDlg::OnBnClickedButton21()
{
	if (!endYet('X', XandO) && !endYet('O', XandO))
	if (isEmpty(XandO[1][0])) {
		setFont(10, false);
		GetDlgItem(IDC_BUTTON21)->SetWindowTextW(L"X");
		XandO[1][0] = 'X';
		endGame('X', XandO);
		if (!(tieYet(XandO) || endYet('X', XandO) || endYet('O', XandO))) {
			AI(XandO);
		}
	}
}


void CTikTakToeUIDlg::OnBnClickedButton22()
{
	if (!endYet('X', XandO) && !endYet('O', XandO))
	if (isEmpty(XandO[1][1])) {
		setFont(11, false);
		GetDlgItem(IDC_BUTTON22)->SetWindowTextW(L"X");
		XandO[1][1] = 'X';
		endGame('X', XandO);
		if (!(tieYet(XandO) || endYet('X', XandO) || endYet('O', XandO))) {
			AI(XandO);
		}
	}
}


void CTikTakToeUIDlg::OnBnClickedButton23()
{
	if (!endYet('X', XandO) && !endYet('O', XandO))
	if (isEmpty(XandO[1][2])) {
		setFont(12, false);
		GetDlgItem(IDC_BUTTON23)->SetWindowTextW(L"X");
		XandO[1][2] = 'X';
		endGame('X', XandO);
		if (!(tieYet(XandO) || endYet('X', XandO) || endYet('O', XandO))) {
			AI(XandO);
		}
	}
}


void CTikTakToeUIDlg::OnBnClickedButton31()
{
	if (!endYet('X', XandO) && !endYet('O', XandO))
	if (isEmpty(XandO[2][0])) {
		setFont(20, false);
		GetDlgItem(IDC_BUTTON31)->SetWindowTextW(L"X");
		XandO[2][0] = 'X';
		endGame('X', XandO);
		if (!(tieYet(XandO) || endYet('X', XandO) || endYet('O', XandO))) {
			AI(XandO);
		}
	}
}


void CTikTakToeUIDlg::OnBnClickedButton32()
{
	if (!endYet('X', XandO) && !endYet('O', XandO))
	if (isEmpty(XandO[2][1])) {
		setFont(21, false);
		GetDlgItem(IDC_BUTTON32)->SetWindowTextW(L"X");
		XandO[2][1] = 'X';
		endGame('X', XandO);
		if (!(tieYet(XandO) || endYet('X', XandO) || endYet('O', XandO))) {
			AI(XandO);
		}
	}
}


void CTikTakToeUIDlg::OnBnClickedButton33()
{
	if (!endYet('X', XandO) && !endYet('O', XandO))
	if (isEmpty(XandO[2][2])) {
		setFont(22, false);
		GetDlgItem(IDC_BUTTON33)->SetWindowTextW(L"X");
		XandO[2][2] = 'X';
		endGame('X', XandO);
		if (!(tieYet(XandO) || endYet('X', XandO) || endYet('O', XandO))) {
			AI(XandO);
		}
	}
}

void CTikTakToeUIDlg::OnBnClickedCancel()
{
	CDialogEx::OnCancel();
}

void CTikTakToeUIDlg::OnBnClickedCancel2()
{
	if (!allEmpty(XandO)) {
		int buttonCode=0;
		int score;
		if(!(endYet('X', XandO) || endYet('O', XandO) || tieYet(XandO))) {
			loss++;
			buttonCode = IDC_STATIC7;
			score = loss;
		}
		if (!buttonCode==0) {
			char tmpStr[10] = { '\0' };
			sprintf_s(tmpStr, "%d", score);
			size_t newsize = strlen(tmpStr) + 1;
			wchar_t* printScore = new wchar_t[newsize];
			size_t convertedChars = 0;
			mbstowcs_s(&convertedChars, printScore, newsize, tmpStr, _TRUNCATE);
			GetDlgItem(buttonCode)->SetWindowTextW(printScore);
		}
	}
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			GetDlgItem(getButton(i * 10 + j))->SetWindowTextW(L"");
			setFont(i*10+j, false);
			XandO[i][j] = ' ';
		}
	}
}
